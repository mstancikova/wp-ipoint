BizzMix theme by NewWpThemes, http://newwpthemes.com
Online Demo: http://newwpthemes.com/demo/BizzMix/
Theme URI: http://newwpthemes.com/bizzmix-free-wordpress-theme/